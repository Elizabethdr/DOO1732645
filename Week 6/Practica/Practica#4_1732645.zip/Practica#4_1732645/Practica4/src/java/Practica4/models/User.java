/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Practica4.models;

/**
 *
 * @author Diana Díaz Rodríguez
 */
public class User {
    
    private String username;
    private String password;
    public String emailDataBase;
    public String nombreDataBase;
    public String apellidosDataBase;
    public String ocupacionDataBase;
     
    
    public User(){
        this.username = "Diana";
        this.password = "MiPassword";
        emailDataBase = "eli_diaz134@hotmail.com";
        nombreDataBase = "Diana";
        apellidosDataBase = "Díaz";
        ocupacionDataBase = "Estudiante";
                        
    }
    
    public String getUsername(){
        return this.username;
    }
    
    public String getPassword(){
        return this.password;
    }
    
    public String getEmail(){
        return emailDataBase;
    }
    
    public String getName(){
        return nombreDataBase;
    }
    
    public String getApellidos(){
        return apellidosDataBase;
    }
    
    public String getOcupacion(){
        return ocupacionDataBase;
    }
}
