/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.Connection;
import java.sql.*;
import java.util.*;

/**
 *
 * @author Diana Díaz Rodriguez 1732645
 */
public class ComentariosDAO {
    
    private Connection conexion;
    
    private void abrirConexion() throws SQLException {
        String dbURI = "jdbc:derby://localhost:1527/Comentarios";
        
        String username = "fcfm";
        String password = "lsti01";
        conexion = DriverManager.getConnection(dbURI, username, password);
    }
    
    private void cerrarConexion() throws SQLException {
        conexion.close();
    }
    
    
    public boolean insertar( ComentariosPOJO dto) throws SQLException{
        
        try{
            abrirConexion();
               
        dto.getComentario();
        dto.getNombre();
        
        String insert = "insert into COMENTARIOS values ('" + dto.getNombre() + "' , '" + dto.getComentario() +"')";
        Statement stmt = conexion.createStatement();
        stmt.executeUpdate(insert);
        conexion.close();
        return true;
        
        
    }catch (Exception e){
        return false;
    }
    
    /**
     *
     * @param dto
     * @return
     */
    public ArrayList <ComentariosPOJO> buscar(ComentariosPOJO dto){
            
        try{
            abrirConexion();
            String select = "select nombre, comentario from comentario where nombre = '" + dto.getNombre() + "' , '" + dto.getComentario() + "'";
            
            ArrayList<ComentariosPOJO> comentariosList = new ArrayList();
            Statement statement = conexion.createStatement();
            ResultSet result = statement.executeQuery(select);
            
            while(result.next()){
                ComentariosPOJO comentario = new ComentariosPOJO();
                comentario.setNombre(result.getString("Nombre"));
                comentario.setComentario(result.getString("Comentario"));
                comentariosList.add(comentario);
            }
            conexion.close();
        }catch(Exception e){
            
        }
    }
    
    
}
