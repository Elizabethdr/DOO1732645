/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laboratorio6.models;

/**
 *
 * @author Diana Díaz Rodríguez
 */
public class User {
    private String username;
    private String password;
    private String name;
    private String apellidos;
        
    
    public User(String username,String password){
        this.username=username;
        this.password=password;
        this.name = "Diana";
        this.apellidos = "Diaz Rodriguez";
        
    }
    
    public String getUsername(){
        return this.username;
    }
    
    public String getName(){
        return this.name;
    }
    
    public String getLastName(){
        return this.apellidos;
    }
    
    public String getFullName(){
        return getName() + " " + getLastName();
    }
    
}

